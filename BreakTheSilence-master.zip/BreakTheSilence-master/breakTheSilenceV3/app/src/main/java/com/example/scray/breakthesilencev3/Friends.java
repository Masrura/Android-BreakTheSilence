package com.example.scray.breakthesilencev3;

/**
 * Created by debasr on 13/02/19.
 */

public class Friends {

    public String date;

    public Friends(){

    }

    public Friends(String date) {
        this.date = date;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
