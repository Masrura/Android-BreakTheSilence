package com.example.scray.breakthesilencev3.Notifications;

public class MyResponse {

    public int success;
}
